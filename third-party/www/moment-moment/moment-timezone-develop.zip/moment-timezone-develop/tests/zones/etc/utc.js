"use strict";

var helpers = require("../../helpers/helpers");

exports["Etc/UTC"] = {

};