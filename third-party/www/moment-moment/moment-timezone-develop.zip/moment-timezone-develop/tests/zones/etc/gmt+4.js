"use strict";

var helpers = require("../../helpers/helpers");

exports["Etc/GMT+4"] = {

};