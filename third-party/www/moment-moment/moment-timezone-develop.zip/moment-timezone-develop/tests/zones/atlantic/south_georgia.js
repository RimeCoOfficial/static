"use strict";

var helpers = require("../../helpers/helpers");

exports["Atlantic/South_Georgia"] = {

};