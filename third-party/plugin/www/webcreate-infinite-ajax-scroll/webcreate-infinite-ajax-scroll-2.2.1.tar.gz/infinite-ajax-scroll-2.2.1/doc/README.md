All documentation is made available at http://infiniteajaxscroll.com/docs.
