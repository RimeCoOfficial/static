window.localforage = require('./../dist/localforage');
